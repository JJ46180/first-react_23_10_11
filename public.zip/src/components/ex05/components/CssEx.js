// import "../css/style.css";

export const CssEx = () => {
  return (
    <div>
      <div
        className="box"
        style={{ width: "300px", height: "300px", backgroundColor: "red" }}
      >
        1번박스
      </div>

      <div className="box_2">2번박스</div>
    </div>
  );
};
