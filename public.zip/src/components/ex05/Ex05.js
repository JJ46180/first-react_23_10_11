import { CssEx } from "./components/CssEx";
import { StyledEx } from "./components/StyledEx";

export const Ex05 = () => {
  return (
    <div>
      <CssEx />
      <StyledEx />
    </div>
  );
};
